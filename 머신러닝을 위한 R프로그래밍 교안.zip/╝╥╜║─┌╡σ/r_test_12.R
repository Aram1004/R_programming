#�Լ�:� ����� �����ϴ� ��
funTest <- function(x,j){ #�Լ� ����
  print(x+1)
  print(j+2)
}

#�Լ� ȣ��
funTest(j=3,x=4)


f<-function(...){
  mylist<-list(...)
  class(mylist)
  print(mylist)
    for (i in mylist){
      print(i)
    }
  }

f(3,4,5)


f2<-function(a,b){
  print(a)
  print(b)
}
g2<-function(c, ...){
  print(c)
  f2(...)
}

g2(10,20,30)


f3<-function(a,b){
  print(a)
g3<-function(b){
  print(b)
}
g3(b)
}

f3(10,20)


f4<-function(a){
  return(function(b){
    return(a+b)
  })
}

g4<-f4(1)
print(g4)
g4(2)

g4<-f4(10)
g4(20)







