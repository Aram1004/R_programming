class(1)
class(c(1,2,3))
x<-5
class(x)
class(matrix(c(1,2)))
class(data.frame(a=c(1,2), b=c(3,4)))
str(c(1,2))
str(matrix(c(5,6)))
str(list(c(5,6)))
is.factor(factor(c("m","f")))
is.numeric(5:10)
is.character(c("g","h"))
is.data.frame(data.frame(a=1:3))

x<-(c("g","h"))
class(x)
y<-as.factor(x)
class(y)
class(x)

z<-as.character(y)
z
class(z)
a<-matrix(1:6, ncol=2)
a
class(a)
x2<-as.data.frame(a)
x2
r=list(x=c(10,20), y=c(30,40))
r
class(r)
r2<-as.list(r)
r2
r3<-as.data.frame(r2)
r3
class(r3)

bt<-c("a", "b", "o", "ab")
class(bt)

fbt<-as.factor(bt)
fbt

factor(c("a", "b", "o", "ab"), levels = c("a","b","o","ab"))

